package border_controll;

public interface Identifiable {

    String getId();

}